# Sisteminha Flask do Promotor — com SQLAlchemy de verdade
from flask import Flask, render_template, request, redirect, url_for, session, send_file
from werkzeug.utils import secure_filename
from datetime import datetime
from io import BytesIO
from flask_sqlalchemy import SQLAlchemy
import pandas as pd
import os

app = Flask(__name__)
app.secret_key = 'meu_segredo_triste'

UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Configuração do banco de dados
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///promotor.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(80), unique=True, nullable=False)
    senha = db.Column(db.String(120), nullable=False)
    status = db.Column(db.String(20), default='ativo')  # Ex: 'ativo', 'inativo'
    horario = db.Column(db.String(20))  # Ex: '08:00-17:00'
    id_estado = db.Column(db.Integer)
    cpf_cnpj = db.Column(db.String(20))
    id_cto = db.Column(db.Integer)

    registros = db.relationship('RegistroJornada', backref='usuario', lazy=True)
    pesquisas = db.relationship('PesquisaPreco', backref='usuario', lazy=True)
    id_horario = db.Column(db.Integer, db.ForeignKey('horario.id'))
    horario = db.relationship('Horario')
    id_tipo_user = db.Column(db.Integer, db.ForeignKey('tipo_usuario.id'))

class RegistroJornada(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    data = db.Column(db.String(10), nullable=False)
    entrada = db.Column(db.String(8))
    pausa = db.Column(db.String(8))
    retorno = db.Column(db.String(8))
    saida = db.Column(db.String(8))
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuario.id'), nullable=False)

class PesquisaPreco(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    mercado = db.Column(db.String(100), nullable=False)
    produto = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(30), default='pendente')
    foto = db.Column(db.String(200))
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuario.id'), nullable=False)
    motivo_recusa = db.Column(db.String(255))

class Horario(db.Model):
    __tablename__ = 'horario'
    id = db.Column(db.Integer, primary_key=True)
    descricao = db.Column(db.String(100), nullable=False)
    entrada = db.Column(db.String(10))
    pausa = db.Column(db.String(10))
    fim = db.Column(db.String(10))
    id_tipo_user = db.Column(db.Integer, db.ForeignKey('tipo_usuario.id'))

    tipo_usuario = db.relationship('TipoUsuario', back_populates='horarios')


class TipoUsuario(db.Model):
    __tablename__ = 'tipo_usuario'
    id = db.Column(db.Integer, primary_key=True)
    descricao = db.Column(db.String(100), nullable=False)

    usuarios = db.relationship('Usuario', backref='tipo_usuario', lazy=True)
    horarios = db.relationship('Horario', back_populates='tipo_usuario', lazy=True)


with app.app_context():
    db.create_all()

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        usuario = request.form['usuario']
        senha = request.form['senha']

        if usuario == 'auditor' and senha == 'admin':
            session['auditor'] = usuario
            return redirect(url_for('painel_auditor'))

        user = Usuario.query.filter_by(nome=usuario, senha=senha).first()
        if user and user.status == 'ativo':
            session['usuario_id'] = user.id
            return redirect(url_for('painel'))
        else:
            return "Login inválido ou usuário inativo."
    
    return render_template('login.html')



@app.route('/painel', methods=['GET', 'POST'])
def painel():
    if 'usuario_id' not in session:
        return redirect(url_for('login'))

    usuario = Usuario.query.get(session['usuario_id'])

    if request.method == 'POST':
        if 'acao' in request.form and request.form['acao'] in ['entrada', 'pausa', 'retorno', 'saida']:
            acao = request.form['acao']
            now = datetime.now()
            date_key = now.strftime('%Y-%m-%d')
            hora = now.strftime('%H:%M:%S')

            registro = RegistroJornada.query.filter_by(usuario_id=usuario.id, data=date_key).first()
            if not registro:
                registro = RegistroJornada(usuario_id=usuario.id, data=date_key)
                db.session.add(registro)
            setattr(registro, acao, hora)
            db.session.commit()

        elif 'pesquisa_id' in request.form:
            pesquisa_id = int(request.form['pesquisa_id'])
            foto = request.files['foto']
            if foto:
                pesquisa = PesquisaPreco.query.get(pesquisa_id)
                if pesquisa and pesquisa.usuario_id == usuario.id:
                    filename = secure_filename(f"{usuario.nome}_pesquisa_{pesquisa_id}.jpg")
                    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                    foto.save(filepath)
                    pesquisa.foto = filename
                    pesquisa.status = 'aguardando_aprovacao'
                    db.session.commit()

    registros = RegistroJornada.query.filter_by(usuario_id=usuario.id).all()
    pesquisas_pendentes = PesquisaPreco.query.filter_by(usuario_id=usuario.id).filter(PesquisaPreco.status != 'aprovada').all()
    pesquisas_concluidas = PesquisaPreco.query.filter_by(usuario_id=usuario.id, status='aprovada').all()

    hoje = datetime.now().strftime('%Y-%m-%d')
    registro_hoje = RegistroJornada.query.filter_by(usuario_id=usuario.id, data=hoje).first()

    status = {
    'entrada': 'Registrado' if registro_hoje and registro_hoje.entrada else 'Sem registro',
    'pausa': 'Registrado' if registro_hoje and registro_hoje.pausa else 'Sem registro',
    'retorno': 'Registrado' if registro_hoje and registro_hoje.retorno else 'Sem registro',
    'saida': 'Registrado' if registro_hoje and registro_hoje.saida else 'Sem registro',
}

    checkins = {
    'entrada': registro_hoje.entrada if registro_hoje else None,
    'pausa': registro_hoje.pausa if registro_hoje else None,
    'retorno': registro_hoje.retorno if registro_hoje else None,
    'saida': registro_hoje.saida if registro_hoje else None,
}

    return render_template(
    'painel.html',
    usuario=usuario.nome,
    registros=registros,
    pesquisas=pesquisas_pendentes,
    concluidas=pesquisas_concluidas,
    status=status,
    checkins=checkins
)


@app.route('/auditor', methods=['GET', 'POST'])
def painel_auditor():
    if 'auditor' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        usuario_id = request.form.get('usuario_id')
        if usuario_id:
            if 'aprovar_pesquisa_id' in request.form:
                pesquisa_id = int(request.form['aprovar_pesquisa_id'])
                pesquisa = PesquisaPreco.query.get(pesquisa_id)
                if pesquisa:
                    pesquisa.status = 'aprovada'
                    db.session.commit()
            elif 'excluir_registro' in request.form:
                acao = request.form['excluir_registro']
                data = request.form['data']
                registro = RegistroJornada.query.filter_by(usuario_id=usuario_id, data=data).first()
                if registro:
                    setattr(registro, acao, None)
                    db.session.commit()
            elif 'destino' in request.form:
                destino = request.form['destino']
                user = Usuario.query.filter_by(nome=destino).first()
                if user:
                    nova = PesquisaPreco(
                        usuario_id=user.id,
                        mercado=request.form['mercado'],
                        produto=request.form['produto'],
                        status='pendente'
                    )
                    db.session.add(nova)
                    db.session.commit()

    usuarios = Usuario.query.filter_by(status='ativo').all()
    return render_template('painel_auditor.html', usuarios=usuarios)

@app.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if 'auditor' not in session:
        return redirect(url_for('login'))

    tipos_usuario = TipoUsuario.query.all()
    horarios = Horario.query.all()

    if request.method == 'POST':
        # Pega tudo do form
        nome = request.form['nome']
        senha = request.form['senha']
        status = request.form['status']
        horario = request.form['horario']
        cpf_cnpj = request.form['cpf_cnpj']
        id_estado = request.form['id_estado']
        id_cto = request.form['id_cto']
        id_tipo_user = request.form.get('id_tipo_user')
        id_horario = request.form.get('id_horario')

        if Usuario.query.filter_by(nome=nome).first():
            return "Usuário já existe!"

        novo = Usuario(
            nome=nome,
            senha=senha,
            status=status,
            horario=horario,
            cpf_cnpj=cpf_cnpj,
            id_estado=id_estado,
            id_cto=id_cto,
            id_tipo_user=id_tipo_user,
            id_horario=id_horario
        )
        db.session.add(novo)
        db.session.commit()
        return redirect(url_for('listar_usuarios'))

    return render_template('cadastro.html', tipos_usuario=tipos_usuario, horarios=horarios)


@app.route('/usuarios')
def listar_usuarios():
    if 'auditor' not in session:
        return redirect(url_for('login'))

    usuarios = Usuario.query.all()
    return render_template('usuarios.html', usuarios=usuarios)

@app.route('/editar_usuario/<int:id>', methods=['GET', 'POST'])
def editar_usuario(id):
    usuario = Usuario.query.get_or_404(id)
    tipos_usuario = TipoUsuario.query.all()
    horarios = Horario.query.all()

    if request.method == 'POST':
        usuario.nome = request.form['nome']
        usuario.senha = request.form['senha']
        usuario.status = request.form['status']
        usuario.id_horario = request.form['id_horario']
        usuario.cpf_cnpj = request.form['cpf_cnpj']
        usuario.id_estado = request.form['id_estado']
        usuario.id_cto = request.form['id_cto']
        usuario.id_tipo_user = request.form.get('id_tipo_user')
        usuario.id_horario = request.form.get('id_horario')
        db.session.commit()
        return redirect(url_for('listar_usuarios'))

    return render_template('editar_usuario.html', usuario=usuario, tipos_usuario=tipos_usuario, horarios=horarios)




from datetime import datetime

@app.route('/auditor/usuario/<int:usuario_id>')
def detalhes_usuario(usuario_id):
    if 'auditor' not in session:
        return redirect(url_for('login'))

    usuario = Usuario.query.get_or_404(usuario_id)
    registros = RegistroJornada.query.filter_by(usuario_id=usuario.id).all()
    pesquisas = PesquisaPreco.query.filter_by(usuario_id=usuario.id).all()
    current_year = datetime.now().year  # 👈 adiciona isso

    return render_template(
        'detalhes_usuario.html',
        usuario=usuario,
        registros=registros,
        pesquisas=pesquisas,
        current_year=current_year  # 👈 passa pra o HTML
    )



@app.route('/pesquisas')
def listar_pesquisas():
    if 'auditor' not in session:
        return redirect(url_for('login'))

    pesquisas = PesquisaPreco.query.all()
    return render_template('pesquisas.html', pesquisas=pesquisas)

@app.route('/pesquisa/<int:id>', methods=['GET', 'POST'])
def detalhes_pesquisa(id):
    if 'auditor' not in session:
        return redirect(url_for('login'))

    pesquisa = PesquisaPreco.query.get_or_404(id)

    if request.method == 'POST':
        acao = request.form.get('acao')
        if acao == 'aprovar':
            pesquisa.status = 'aprovada'
            pesquisa.motivo_recusa = None
        elif acao == 'recusar':
            pesquisa.status = 'recusada'
            pesquisa.motivo_recusa = request.form.get('motivo_recusa')
        db.session.commit()
        return redirect(url_for('listar_pesquisas'))

    return render_template('detalhes_pesquisa.html', pesquisa=pesquisa)

@app.route('/nova_pesquisa', methods=['GET', 'POST'])
def nova_pesquisa():
    if 'auditor' not in session:
        return redirect(url_for('login'))

    usuarios = Usuario.query.filter_by(status='ativo').all()

    if request.method == 'POST':
        mercado = request.form['mercado']
        produto = request.form['produto']
        usuario_id = request.form['usuario_id']
        nova = PesquisaPreco(mercado=mercado, produto=produto, usuario_id=usuario_id)
        db.session.add(nova)
        db.session.commit()
        return redirect(url_for('listar_pesquisas'))

    return render_template('nova_pesquisa.html', usuarios=usuarios)

from datetime import datetime

@app.route('/jornada/<int:usuario_id>/filtro')
def filtro_jornada(usuario_id):
    ano = request.args.get('ano')
    mes = request.args.get('mes')

    if not ano or not mes:
        return "Ano e mês são obrigatórios", 400

    usuario = Usuario.query.get_or_404(usuario_id)
    registros_filtrados = RegistroJornada.query.filter(
        RegistroJornada.usuario_id == usuario_id,
        RegistroJornada.data.like(f"{ano}-{mes}-%")
    ).all()

    return render_template('registros_filtrados.html', usuario=usuario, registros=registros_filtrados, ano=ano, mes=mes)


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
